<?php
require_once "conexion.php";

$sql = "SELECT * FROM productos ORDER BY id DESC";
$resultado = $conexion->query($sql);

$productos = [];

if ($resultado) {
    while ($fila = $resultado->fetch_assoc()) {
        $productos[] = $fila;
    }
}

$totalProductos = count($productos);
$totalDisponibles = 0;
$totalUnidades = 0;

foreach ($productos as $producto) {
    if ((int)$producto['disponible'] === 1) {
        $totalDisponibles++;
    }

    $totalUnidades += (int)$producto['stock'];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Tienda Deportiva | Inventario</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #0b1120;
            color: #e5e7eb;
            margin: 0;
            min-height: 100vh;
        }

        .barra-superior {
            background: #111827;
            border-bottom: 1px solid #263244;
            padding: 20px 5%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            flex-wrap: wrap;
        }

        .marca {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo {
            width: 46px;
            height: 46px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #a3e635;
            color: #111827;
            border-radius: 12px;
            font-size: 23px;
            font-weight: bold;
        }

        .marca h2 {
            margin: 0;
            font-size: 20px;
            color: white;
        }

        .marca span {
            display: block;
            margin-top: 5px;
            color: #9ca3af;
            font-size: 12px;
        }

        .estado-sistema {
            color: #a3e635;
            font-size: 13px;
            background: #1c2a1b;
            border: 1px solid #365329;
            padding: 9px 13px;
            border-radius: 20px;
        }

        .contenedor {
            width: 90%;
            max-width: 1250px;
            margin: 35px auto;
        }

        .encabezado {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 28px;
        }

        .encabezado h1 {
            margin: 0;
            font-size: 30px;
            color: white;
        }

        .encabezado p {
            color: #9ca3af;
            margin: 10px 0 0;
            font-size: 14px;
        }

        .boton-registrar {
            display: inline-block;
            padding: 13px 18px;
            border-radius: 8px;
            background: #a3e635;
            color: #17200d;
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
            transition: 0.2s;
        }

        .boton-registrar:hover {
            background: #bef264;
            transform: translateY(-2px);
        }

        .estadisticas {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
            margin-bottom: 30px;
        }

        .tarjeta {
            background: #151e2e;
            border: 1px solid #273449;
            border-radius: 12px;
            padding: 23px;
        }

        .tarjeta .titulo {
            color: #9ca3af;
            font-size: 14px;
            margin-bottom: 15px;
        }

        .tarjeta .numero {
            color: white;
            font-size: 30px;
            font-weight: bold;
        }

        .tarjeta .detalle {
            color: #a3e635;
            font-size: 12px;
            margin-top: 10px;
        }

        .panel {
            background: #151e2e;
            border: 1px solid #273449;
            border-radius: 12px;
            overflow: hidden;
        }

        .panel-encabezado {
            padding: 22px 24px;
            border-bottom: 1px solid #273449;
        }

        .panel-encabezado h2 {
            margin: 0;
            color: white;
            font-size: 19px;
        }

        .panel-encabezado p {
            margin: 8px 0 0;
            color: #9ca3af;
            font-size: 13px;
        }

        .tabla-contenedor {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            min-width: 850px;
            border-collapse: collapse;
        }

        th {
            background: #101827;
            color: #9ca3af;
            padding: 16px 18px;
            font-size: 11px;
            text-align: left;
            text-transform: uppercase;
            letter-spacing: 0.7px;
            white-space: nowrap;
        }

        td {
            padding: 17px 18px;
            border-bottom: 1px solid #273449;
            color: #d1d5db;
            font-size: 13px;
            text-align: left;
        }

        tbody tr {
            transition: background 0.2s;
        }

        tbody tr:hover {
            background: #1b273a;
        }

        tbody tr:last-child td {
            border-bottom: none;
        }

        .id-producto {
            color: #a3e635;
            font-weight: bold;
        }

        .nombre-producto {
            color: white;
            font-weight: bold;
        }

        .precio {
            color: #a3e635;
            font-weight: bold;
            white-space: nowrap;
        }

        .etiqueta {
            display: inline-block;
            padding: 6px 9px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: bold;
            white-space: nowrap;
        }

        .disponible {
            background: #193d2b;
            color: #86efac;
        }

        .no-disponible {
            background: #482329;
            color: #fca5a5;
        }

        .acciones {
            display: flex;
            align-items: center;
            gap: 7px;
        }

        .boton-editar,
        .boton-eliminar {
            display: inline-block;
            padding: 8px 10px;
            border: none;
            border-radius: 6px;
            color: white;
            font-size: 12px;
            font-weight: bold;
            text-decoration: none;
            cursor: pointer;
            font-family: inherit;
        }

        .boton-editar {
            background: #1d4ed8;
        }

        .boton-editar:hover {
            background: #2563eb;
        }

        .boton-eliminar {
            background: #991b1b;
        }

        .boton-eliminar:hover {
            background: #dc2626;
        }

        .form-eliminar {
            display: inline;
            margin: 0;
        }

        .sin-productos {
            padding: 45px 20px;
            text-align: center;
            color: #9ca3af;
        }

        .sin-productos strong {
            display: block;
            color: white;
            font-size: 17px;
            margin-bottom: 10px;
        }

        .pie-tabla {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            flex-wrap: wrap;
            padding: 18px 24px;
            border-top: 1px solid #273449;
            color: #9ca3af;
            font-size: 12px;
        }

        .pie-pagina {
            text-align: center;
            color: #64748b;
            font-size: 12px;
            padding: 25px 10px;
        }

        @media (max-width: 750px) {
            .contenedor {
                width: 94%;
                margin: 25px auto;
            }

            .estadisticas {
                grid-template-columns: 1fr;
                gap: 12px;
            }

            .encabezado h1 {
                font-size: 24px;
            }

            .tarjeta {
                padding: 18px;
            }

            .tarjeta .numero {
                font-size: 26px;
            }

            .barra-superior {
                padding: 16px 4%;
            }
        }
    </style>
</head>

<body>

<header class="barra-superior">
    <div class="marca">
        <div class="logo">TD</div>

        <div>
            <h2>SPORT CENTER</h2>
            <span>Administración de inventario</span>
        </div>
    </div>

    <div class="estado-sistema">
        ● Sistema de inventario
    </div>
</header>

<main class="contenedor">

    <section class="encabezado">
        <div>
            <h1>Panel de productos</h1>
            <p>Administra los productos de tu tienda deportiva.</p>
        </div>

        <a href="registrar.php" class="boton-registrar">
            + Registrar producto
        </a>
    </section>

    <section class="estadisticas">

        <div class="tarjeta">
            <div class="titulo">Productos registrados</div>
            <div class="numero">
                <?= $totalProductos ?>
            </div>
            <div class="detalle">Total de registros</div>
        </div>

        <div class="tarjeta">
            <div class="titulo">Productos disponibles</div>
            <div class="numero">
                <?= $totalDisponibles ?>
            </div>
            <div class="detalle">Marcados como disponibles</div>
        </div>

        <div class="tarjeta">
            <div class="titulo">Unidades en inventario</div>
            <div class="numero">
                <?= number_format($totalUnidades) ?>
            </div>
            <div class="detalle">Suma de todas las existencias</div>
        </div>

    </section>

    <section class="panel">

        <div class="panel-encabezado">
            <h2>Inventario de productos</h2>
            <p>Consulta y administra los artículos registrados.</p>
        </div>

        <div class="tabla-contenedor">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Producto</th>
                        <th>Marca</th>
                        <th>Categoría</th>
                        <th>Precio</th>
                        <th>Stock</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>

                <tbody>

                <?php if ($totalProductos > 0): ?>

                    <?php foreach ($productos as $producto): ?>

                        <tr>
                            <td class="id-producto">
                                #<?= (int)$producto['id'] ?>
                            </td>

                            <td class="nombre-producto">
                                <?= htmlspecialchars($producto['nombre'], ENT_QUOTES, 'UTF-8') ?>
                            </td>

                            <td>
                                <?= htmlspecialchars($producto['marca'], ENT_QUOTES, 'UTF-8') ?>
                            </td>

                            <td>
                                <?= htmlspecialchars($producto['categoria'], ENT_QUOTES, 'UTF-8') ?>
                            </td>

                            <td class="precio">
                                $<?= number_format((float)$producto['precio'], 2) ?>
                            </td>

                            <td>
                                <?= (int)$producto['stock'] ?> unidades
                            </td>

                            <td>
                                <?php if ((int)$producto['disponible'] === 1): ?>
                                    <span class="etiqueta disponible">
                                        Disponible
                                    </span>
                                <?php else: ?>
                                    <span class="etiqueta no-disponible">
                                        No disponible
                                    </span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <div class="acciones">

                                    <a
                                        href="editar.php?id=<?= (int)$producto['id'] ?>"
                                        class="boton-editar">
                                        Editar
                                    </a>

                                    <form
                                        action="eliminar.php"
                                        method="POST"
                                        class="form-eliminar"
                                        onsubmit="return confirm('¿Estás seguro de eliminar este producto?');">

                                        <input
                                            type="hidden"
                                            name="id"
                                            value="<?= (int)$producto['id'] ?>">

                                        <button
                                            type="submit"
                                            class="boton-eliminar">
                                            Eliminar
                                        </button>

                                    </form>

                                </div>
                            </td>
                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>
                        <td colspan="8">
                            <div class="sin-productos">
                                <strong>No hay productos registrados</strong>
                                Agrega tu primer producto para comenzar a administrar el inventario.
                                <br><br>
                                <a href="registrar.php" class="boton-registrar">
                                    + Agregar producto
                                </a>
                            </div>
                        </td>
                    </tr>

                <?php endif; ?>

                </tbody>
            </table>
        </div>

        <div class="pie-tabla">
            <span>
                Mostrando <?= $totalProductos ?>
                <?= $totalProductos === 1 ? 'producto' : 'productos' ?>
            </span>

            <span>Inventario de SPORT CENTER</span>
        </div>

    </section>

</main>

<footer class="pie-pagina">
    SPORT CENTER · Sistema de administración de productos deportivos
</footer>

</body>
</html>
