<?php
require_once "conexion.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit;
}

if (
    !isset($_POST["id"]) ||
    !ctype_digit($_POST["id"]) ||
    (int) $_POST["id"] < 1
) {
    header("Location: index.php");
    exit;
}

$id = (int) $_POST["id"];

$stmt = $conexion->prepare(
    "DELETE FROM productos WHERE id = ?"
);

$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    $stmt->close();
    header("Location: index.php");
    exit;
}

$stmt->close();

echo "No se pudo eliminar el producto.";
echo '<br><a href="index.php">Volver al inventario</a>';
?>
