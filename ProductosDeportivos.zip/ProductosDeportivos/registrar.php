<?php
require_once "conexion.php";

$mensaje = "";

$nombre = "";
$marca = "";
$categoria = "";
$precio = "";
$stock = "";
$disponible = "1";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre = trim($_POST["nombre"] ?? "");
    $marca = trim($_POST["marca"] ?? "");
    $categoria = trim($_POST["categoria"] ?? "");
    $precio = $_POST["precio"] ?? "";
    $stock = $_POST["stock"] ?? "";
    $disponible = $_POST["disponible"] ?? "";

    if (
        $nombre === "" ||
        $marca === "" ||
        $categoria === "" ||
        !is_numeric($precio) ||
        !is_finite((float)$precio) ||
        (float)$precio < 0 ||
        filter_var($stock, FILTER_VALIDATE_INT) === false ||
        (int)$stock < 0 ||
        !in_array($disponible, ["0", "1"], true)
    ) {
        $mensaje = "Verifica los datos ingresados.";
    } else {
        $sql = "INSERT INTO productos
                (nombre, marca, categoria, precio, stock, disponible)
                VALUES (?, ?, ?, ?, ?, ?)";

        $stmt = $conexion->prepare($sql);

        $precio = (float)$precio;
        $stock = (int)$stock;
        $disponible = (int)$disponible;

        $stmt->bind_param(
            "sssdii",
            $nombre,
            $marca,
            $categoria,
            $precio,
            $stock,
            $disponible
        );

        if ($stmt->execute()) {
            $stmt->close();
            header("Location: index.php");
            exit;
        } else {
            $mensaje = "Error al registrar el producto.";
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Registrar producto | SPORT CENTER</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #0b1120;
            color: #e5e7eb;
            margin: 0;
            min-height: 100vh;
        }

        .barra-superior {
            background: #111827;
            border-bottom: 1px solid #263244;
            padding: 20px 5%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            flex-wrap: wrap;
        }

        .marca {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo {
            width: 46px;
            height: 46px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #a3e635;
            color: #111827;
            border-radius: 12px;
            font-size: 23px;
            font-weight: bold;
        }

        .marca h2 {
            margin: 0;
            font-size: 20px;
            color: white;
        }

        .marca span {
            display: block;
            margin-top: 5px;
            color: #9ca3af;
            font-size: 12px;
        }

        .estado-sistema {
            color: #a3e635;
            font-size: 13px;
            background: #1c2a1b;
            border: 1px solid #365329;
            padding: 9px 13px;
            border-radius: 20px;
        }

        .contenedor {
            width: 90%;
            max-width: 850px;
            margin: 35px auto;
        }

        .encabezado {
            margin-bottom: 25px;
        }

        .encabezado h1 {
            margin: 0;
            color: white;
            font-size: 30px;
        }

        .encabezado p {
            color: #9ca3af;
            margin-top: 10px;
            font-size: 14px;
            line-height: 1.6;
        }

        .formulario {
            background: #151e2e;
            border: 1px solid #273449;
            border-radius: 12px;
            overflow: hidden;
        }

        .formulario-encabezado {
            padding: 22px 25px;
            border-bottom: 1px solid #273449;
        }

        .formulario-encabezado h2 {
            color: white;
            font-size: 19px;
            margin: 0;
        }

        .formulario-encabezado p {
            color: #9ca3af;
            font-size: 13px;
            margin: 8px 0 0;
        }

        .contenido-formulario {
            padding: 25px;
        }

        .campos {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 22px;
        }

        .campo {
            min-width: 0;
        }

        label {
            display: block;
            color: #d1d5db;
            font-size: 13px;
            font-weight: bold;
            margin-bottom: 9px;
        }

        .obligatorio {
            color: #a3e635;
        }

        input,
        select {
            display: block;
            width: 100%;
            padding: 13px;
            background: #0b1120;
            color: white;
            border: 1px solid #374151;
            border-radius: 7px;
            font-size: 14px;
            outline: none;
            transition: border-color 0.2s;
        }

        input:focus,
        select:focus {
            border-color: #a3e635;
        }

        input::placeholder {
            color: #64748b;
        }

        select option {
            background: #151e2e;
            color: white;
        }

        .ayuda {
            display: block;
            margin-top: 7px;
            color: #9ca3af;
            font-size: 11px;
        }

        .mensaje {
            padding: 13px 15px;
            margin: 0 0 22px;
            background: #482329;
            border: 1px solid #7f1d1d;
            border-radius: 7px;
            color: #fecaca;
            font-size: 13px;
        }

        .acciones {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 28px;
            padding-top: 22px;
            border-top: 1px solid #273449;
        }

        .boton {
            display: inline-block;
            padding: 12px 18px;
            border: none;
            border-radius: 7px;
            text-decoration: none;
            text-align: center;
            font-size: 13px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.2s;
            font-family: inherit;
        }

        .boton-guardar {
            background: #a3e635;
            color: #17200d;
        }

        .boton-guardar:hover {
            background: #bef264;
            transform: translateY(-1px);
        }

        .boton-volver {
            background: #263449;
            color: #e5e7eb;
        }

        .boton-volver:hover {
            background: #374151;
        }

        .pie-pagina {
            text-align: center;
            color: #64748b;
            font-size: 12px;
            padding: 25px 10px;
        }

        @media (max-width: 600px) {
            .contenedor {
                width: 94%;
                margin: 25px auto;
            }

            .campos {
                grid-template-columns: 1fr;
                gap: 18px;
            }

            .encabezado h1 {
                font-size: 25px;
            }

            .contenido-formulario {
                padding: 20px;
            }

            .barra-superior {
                padding: 16px 4%;
            }

            .acciones .boton {
                flex: 1;
            }
        }
    </style>
</head>

<body>

<header class="barra-superior">
    <div class="marca">
        <div class="logo">TD</div>

        <div>
            <h2>SPORT CENTER</h2>
            <span>Administración de inventario</span>
        </div>
    </div>

    <div class="estado-sistema">
        ● Sistema de inventario
    </div>
</header>

<main class="contenedor">

    <section class="encabezado">
        <h1>Registrar producto</h1>
        <p>
            Agrega un nuevo artículo al inventario de tu tienda deportiva.
            Completa los campos para guardar el producto.
        </p>
    </section>

    <section class="formulario">

        <div class="formulario-encabezado">
            <h2>Información del producto</h2>
            <p>Los campos marcados con * son obligatorios.</p>
        </div>

        <div class="contenido-formulario">

            <?php if ($mensaje !== ""): ?>
                <div class="mensaje" role="alert">
                    <?= htmlspecialchars($mensaje, ENT_QUOTES, 'UTF-8') ?>
                </div>
            <?php endif; ?>

            <form action="registrar.php" method="POST">

                <div class="campos">

                    <div class="campo">
                        <label for="nombre">
                            Nombre del producto <span class="obligatorio">*</span>
                        </label>

                        <input
                            type="text"
                            id="nombre"
                            name="nombre"
                            maxlength="100"
                            placeholder="Ej. Balón de fútbol"
                            value="<?= htmlspecialchars($nombre, ENT_QUOTES, 'UTF-8') ?>"
                            required>
                    </div>

                    <div class="campo">
                        <label for="marca">
                            Marca <span class="obligatorio">*</span>
                        </label>

                        <input
                            type="text"
                            id="marca"
                            name="marca"
                            maxlength="60"
                            placeholder="Ej. Adidas"
                            value="<?= htmlspecialchars($marca, ENT_QUOTES, 'UTF-8') ?>"
                            required>
                    </div>

                    <div class="campo">
                        <label for="categoria">
                            Categoría <span class="obligatorio">*</span>
                        </label>

                        <input
                            type="text"
                            id="categoria"
                            name="categoria"
                            maxlength="60"
                            placeholder="Ej. Fútbol"
                            value="<?= htmlspecialchars($categoria, ENT_QUOTES, 'UTF-8') ?>"
                            required>
                    </div>

                    <div class="campo">
                        <label for="precio">
                            Precio ($) <span class="obligatorio">*</span>
                        </label>

                        <input
                            type="number"
                            id="precio"
                            name="precio"
                            min="0"
                            max="999999999999"
                            step="0.01"
                            placeholder="Ej. 599.99"
                            value="<?= htmlspecialchars((string)$precio, ENT_QUOTES, 'UTF-8') ?>"
                            required>

                        <span class="ayuda">
                            Ingresa el precio en pesos mexicanos.
                        </span>
                    </div>

                    <div class="campo">
                        <label for="stock">
                            Existencias (stock) <span class="obligatorio">*</span>
                        </label>

                        <input
                            type="number"
                            id="stock"
                            name="stock"
                            min="0"
                            step="1"
                            placeholder="Ej. 25"
                            value="<?= htmlspecialchars((string)$stock, ENT_QUOTES, 'UTF-8') ?>"
                            required>

                        <span class="ayuda">
                            Cantidad de unidades en inventario.
                        </span>
                    </div>

                    <div class="campo">
                        <label for="disponible">
                            Disponibilidad <span class="obligatorio">*</span>
                        </label>

                        <select id="disponible" name="disponible" required>
                            <option value="1"
                                <?= (string)$disponible === "1" ? "selected" : "" ?>>
                                Disponible
                            </option>

                            <option value="0"
                                <?= (string)$disponible === "0" ? "selected" : "" ?>>
                                No disponible
                            </option>
                        </select>

                        <span class="ayuda">
                            Indica si el producto está disponible para la venta.
                        </span>
                    </div>

                </div>

                <div class="acciones">

                    <button type="submit" class="boton boton-guardar">
                        Guardar producto
                    </button>

                    <a href="index.php" class="boton boton-volver">
                        Volver al inventario
                    </a>

                </div>

            </form>

        </div>
    </section>

</main>

<footer class="pie-pagina">
    SPORT CENTER · Sistema de administración de productos deportivos
</footer>

</body>
</html>
